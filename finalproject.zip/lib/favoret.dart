import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';

class FavoretScreen extends StatelessWidget {
  List mydata = [
    {
      'title': 'Mayo Chickzza',
      'message': '20 \$',
      'image': 'assets/image/Mayo Chickzza.png'
    },
    {
      'title': 'Brunch Box      ',
      'message': '18 \$',
      'image': 'assets/image/Brunch Box.png'
    },
    {
      'title': 'Combo             ',
      'message': '5 \$',
      'image': 'assets/image/Combo.png'
    },
    {
      'title': 'Mayo Original ',
      'message': '15 \$',
      'image': 'assets/image/Mayo Original.png'
    },
    {
      'title': 'Mayo Pizza     ',
      'message': '15 \$',
      'image': 'assets/image/Mayo Pizza Fries.png'
    },
    {
      'title': 'Tasty Doner    ',
      'message': '20 \$',
      'image': 'assets/image/Tasty Doner.png'
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Color(0xff151515),
      child: ListView(
        children: [
          for (int i = 0; i < mydata.length; i++)
            Card(
              //shadowColor:Colors.white,
              // elevation: 10,
              color: Color(0xFF272727),
              child: ListTile(
                title: Text(
                  mydata[i]['title'],
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    fontSize: 25,
                  ),
                ),
                subtitle: Text(
                  mydata[i]['message'],
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Color(0xffff0000),
                    fontSize: 25,
                  ),
                ),
                leading:
                    Image.asset(mydata[i]['image'], width: 80, height: 150),
                trailing: ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: Container(
                    height: 35,
                    width: 50,
                    color: Color(0xff121212),
                    child: IconButton(
                      onPressed: () {},
                      icon: Icon(
                        Icons.add_sharp,
                        color: Color(
                          0xffff0000,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
